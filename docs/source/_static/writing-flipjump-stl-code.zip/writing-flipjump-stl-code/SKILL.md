---
name: writing-flipjump-stl-code
description: Use when the user mentions FlipJump, refers to .fj files, the flipjump standard library, any of its macros (in the bit, hex, hex.pointers, or stl namespaces), or wants to write, debug, assemble, or run a FlipJump program. Orients to the one-instruction language, routes to the authoritative reference at fjdocs.tomhe.app (with the upstream STL source as fallback), and enforces a verification loop that runs every program through the `fj` CLI before declaring it complete.
---

# Writing FlipJump STL code

## What FlipJump is, in three sentences

FlipJump is a one-instruction language. The single instruction is `a;b` — flip the bit at address `a`, then jump to address `b`. Every program — arithmetic, I/O, function calls, the lot — is composed from that op via macros, the most important being the standard library at `flipjump/stl/`.

## Required setup

```bash
pip install flipjump
```

`fj` is on `PATH` after install. Every command in this skill uses that script.

## A complete runnable program

Verified by compiling and running. Use this as the orientation pattern; adapt by changing the body, not the skeleton.

```fj
// program.fj — declare two numbers, add them, print the result, halt.

stl.startup

bit.add w, a, b                   // a += b   (a is mutated; b is preserved)
stl.output "Result: "
bit.print_dec_int w, a
stl.output '\n'

stl.loop                          // halt — every program ends here

// Data lives AFTER stl.loop — executing it would be undefined behaviour.
a: bit.vec w, 17
b: bit.vec w, 25
```

Run: `fj program.fj`. Expected tail of output:

```
Result: 42

Finished by looping after 0.0s (14,885 ops executed; ...).
```

## The single most common first mistake

**Using any `hex.*` operation without first calling its init macro.** Hex ops (`hex.add`, `hex.cmp`, `hex.if`, `hex.mul`, the table-driven pointer ops, etc.) dispatch through precomputed truth tables, and those tables only exist if you call `hex.init` (which builds all of them) or the specific `hex.<op>.init`. Forget it and you'll get a confusing "label not found" / "undefined symbol" error at the macro-resolve phase — the macro you called looks fine; it's a symbol it references that's unbuilt.

Fix that always works: replace `stl.startup` with `stl.startup_and_init_all` at the top of your program. That bundles `stl.startup` + `hex.init` + `stl.ptr_init` + `stl.stack_init 100`, covering hex ops, pointer ops, and the function-call stack. The reason: a small program-space cost in exchange for never having to think about which init you need.

## Bit vs hex — when to pick which

**Bit** ops are direct: explicit `;` flips and `wflip`s. No init, no table cost, smaller program-space per primitive op, slower per useful op when n is large.

**Hex** ops dispatch through a precomputed 256-entry truth table. ~4× faster per nibble in tight loops; costs ~6500 bits of program space for the full `hex.init` (at `w=64`); requires calling the init macro first.

Heuristic: `hex.*` for arithmetic-heavy loops on n-nibble numbers; `bit.*` for control flow, small one-offs, and anything where program space matters more than time.

## Memory model — the one weird thing

Three constants that appear everywhere:

- `w` = machine word width (typically 64).
- `dw` = `2*w`. The size of one FJ op (flip-target word + jump-target word).
- `dbit` = `w`. The offset into a bit-variable's word at which the "data bit" lives.

The non-obvious part: a `bit`, a `hex`, AND a byte all occupy the same `dw` bits of address space — one FJ op. A `bit` uses bit `dbit`; a `hex` uses bits `dbit..dbit+3`; a byte uses bits `dbit..dbit+7`. They're packed into one op, not separate ops.

Concrete consequence: **`hex.ptr_inc ptr` advances `ptr` by `dw`, which is exactly "next FJ op" = "next hex" = "next byte"**. The same `ptr_inc` is correct for both `hex.write_hex_and_inc` and `hex.write_byte_and_inc`. There is NOT a separate "byte-stride" `ptr_inc` — there can't be, because a byte and a hex have the same address footprint.

## Program skeleton

Every program is:

```fj
stl.startup                  // or stl.startup_and_init_all if using hex / pointers / stack
... your code ...
stl.loop                     // halt — terminates by self-looping
... data declarations ...    // bit.bit, bit.vec, hex.hex, hex.vec — MUST live below stl.loop
```

`stl.loop` compiles to `;$ - dw`, an infinite self-jump. Anything past it is unreachable as code, so it's the safe place for data. Data declarations placed ABOVE `stl.loop` get executed as instructions when control falls through; the program will do something undefined and almost certainly wrong.

## Doc-comment vocabulary

Four conventions describe the entire STL at the source level. Read these on any macro page:

- `// Complexity: ...` (or split `Time Complexity:` / `Space Complexity:`) — the `@`-counted cost.
- `// @requires hex.add.init (or hex.init)` — declares an init dependency. Honour it or the compiler errors.
- `// @output-param NAME: ...` — documents a label exported via `> NAME` in the signature.
- `// @Assumes: ...` — a silent precondition the body relies on (e.g. `times <= n`, `dst and src do not alias`). Violating it doesn't always crash; sometimes you just get the wrong answer.

## `n > 0` is a hard precondition for every vector macro

Treat any `n` parameter as requiring `n > 0`. Several macros index `(n-1)*dw` outside their main loop — examples include `bit.idiv`, `hex.sign`, `bit.print_dec_int`, `bit.div_loop` — and `n=0` reads memory at offset `-dw`, with undefined results. Even macros that LOOK safe at `n=0` (because their body is just `rep(n, i) ...`) are still UB at `n=0` by convention. Don't pass `n=0` to ANY vector macro.

## Idioms that work

- **Print a signed number** — `bit.print_dec_int n, x` or `hex.print_int n, x, 0, 0`. Both correctly restore `x` after negation, so you can print the same variable twice in a row and get two identical signed outputs.
- **Aliasing-safe move** — `bit.mov` / `hex.mov` check `dst==src` at compile time via `stl.comp_if1` and skip the work. You don't need to roll your own zero+xor.
- **Carry chaining in hex** — the n-arity `hex.add n, dst, src` brackets its loop with `clear_carry` calls automatically. The single-hex `hex.add dst, src` does NOT auto-clear; the doc says "Relies on the add-carry, and updates it at the end." If you call single-hex `hex.add` standalone (not from inside `hex.add n, ...`), call `hex.add.clear_carry` first or you'll add a stale carry from a previous op.
- **String literals** — `bit.str "Hello"` allocates `(strlen+1)*8` bits (byte-rounded length plus a trailing null), so `bit.print_str` will stop at the null even without explicit length tracking. Even `bit.str ""` allocates 8 zero bits = a usable null terminator.
- **Halt the program** — `stl.loop`. Equivalent to `;$-dw`.

## Things that are easy to misread in FlipJump source

Recognising these up front avoids whole classes of false "this is buggy" conclusions when reading STL source.

- **`addr;` IS the flip operation**, not "no-op then jump-to-fall-through". Every FJ op is two words: flip-target + jump-target. `addr;` is shorthand for the op that flips the bit at `addr` and jumps to the next op in source. Reading `def exact_not dst { dst; }` as "this macro does nothing" is wrong — it flips `dst`. The reason it looks empty: a single FJ op is the WHOLE primitive operation, and `dst;` already says "flip `dst`".

- **Conditional-jump label order is `l0, l1` = "false-branch, true-branch"** in `bit.if x, l0, l1`: `x==0` → jump `l0`; else (`x==1`) → jump `l1`. The FIRST label is the FALSE branch. Macros like `bit.swap` use this in subtle ways (`.if a, a0, a1` followed by `.if b, end, notnot` vs `.if b, notnot, end`) — the label order in `.if` is what makes the swap correct. Reading the order backwards leads to "this macro looks buggy" when it isn't.

- **Arity is part of the macro identity** — `bit.input/1` (reads one byte into a `bit[:8]`), `bit.input/2` (reads n bytes), and `bit.input_bit/1` (reads one bit) are three different macros with different bodies. The fjdocs site always shows the `/<arity>` suffix on links and headings; preserve it when looking macros up. Saying "macro X does Y" without specifying arity loses information — e.g. `hex.pointers.xor_hex_to_flip_ptr` exists at both /1 and /2, with different bodies, and `@Assumes: bit_shift is divisible by 4` belongs only on /2.

- **Aliasing (same address) vs overlapping (distinct addresses, overlapping ranges) are different problems**. Most macros handle `dst==src` correctly because they have a compile-time `stl.comp_if1 (dst-src), ...` check. Almost none handle overlapping ranges (e.g. `bit.swap n, base, base+dw` corrupts because each per-bit swap operates on memory just written by the previous one). When a doc says "Unsafe if dst and src overlap! but safe if they are the exact same address", it means literally that.

A general habit that helps with all four: when claiming a macro behaves a particular way, quote the exact source lines you're reasoning from, and trace concrete values through them. Lots of analysis errors come from reading source with the wrong sign or wrong label order in mind; concrete values catch the inversion.

## Common errors and what they mean

- **"label not found" / "undefined symbol" at macro-resolve phase** → you used a `hex.*` op without calling `hex.init` (or the specific `hex.<op>.init`). Fix by switching `stl.startup` to `stl.startup_and_init_all`.
- **Program runs forever (no `Finished by looping...` line)** → either you forgot `stl.loop` at the end of your code, or a data declaration ended up above it and is being executed as instructions. Move data below `stl.loop`.
- **Program doesn't halt and the cause isn't obvious** → re-run with `fj -d labels.txt program.fj` and read which macros are on the stack at the last executed addresses. The verbose label names point at the macro that ran past where it should have stopped.

## Verification workflow — the loop

Don't declare a program correct because it compiled. Run it.

1. **Write** the `.fj` file: `stl.startup` (or `stl.startup_and_init_all`), your code, `stl.loop`, then data.
2. **Run** with `fj program.fj` (assembles and runs in one shot). Pipe in stdin if needed.
3. **Read the output.** The success signal is the `Finished by looping after N ops executed; ...` line at the end.
4. **If wrong output or no halt**, fix and repeat from step 2.

A FlipJump program is done when BOTH:
- The `Finished by looping ...` line is present (the program reached `stl.loop` and halted cleanly).
- Everything stdout-printed BEFORE that final line matches the intended output exactly.

If either fails, change the program and rerun. The reason "compiled successfully" isn't enough: compile success only means the macros expanded and labels resolved. It says nothing about whether the runtime produces the output you intended.

## Where to find authoritative reference

Don't rely on memory for exact macro signatures — they're easy to get subtly wrong (arity, parameter order, `< require` clauses). Fetch the right page when in doubt.

**Primary**: https://fjdocs.tomhe.app — the rendered, navigable documentation site. Prefer it for everything.

**Fallback** (only when fjdocs is unreachable): the upstream source at https://github.com/tomhea/flip-jump/tree/main/flipjump/stl.

Common routing (full map in [`reference/docs-map.md`](reference/docs-map.md)):

| Question | Where to look |
|---|---|
| What does `bit.X` / `hex.X` / `stl.X` do? | `/stl/all_macros.html` — alphabetical index with 1-line summaries. |
| Full signature + complexity of one macro | `/stl/<file>/<macro>--<arity>.html`. |
| Which `*.init` does a hex op need? | The `@requires` line on that macro's page. |
| What does `@`, `dw`, `dbit` mean? | `/language/complexity.html` (and `/reference/glossary.html`). |
| How does FJ macro syntax work? | `/language/macros.html`. |
| A cookbook recipe for task X | `/cookbook/index.html`. |
| Concept overview (e.g. how table dispatch works) | `/reference/how-the-stl-works.html`. |
| Program structure, startup, halt | `/getting-started/anatomy.html`. |

For tool details (assembling, running, debugging, plus the testing infrastructure for contributing to flipjump), see [`reference/fj-tool.md`](reference/fj-tool.md).
